<div class="row">
	<div class="col-xs-12">
		<div class="jumbotron">
			<h1><?php echo lang("session_timeout") ?></h1>
  			<p><?php echo lang("msg_session_expired"); ?></p>
			<br><br>
		</div>
	</div>
</div>
<?php 
	
	/*
	<p class="pull-right"><a class="btn btn-primary btn-lg" href="<?php echo base_url("contact")?>" role="button"><?php echo lang("found_a_bug") ?></a></p>
	*/
?>