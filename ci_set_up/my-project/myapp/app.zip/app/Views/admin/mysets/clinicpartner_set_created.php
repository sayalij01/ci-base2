<?php

$set_components = $data["set_data"]["components"];
$lang = $data["language"];

?>
