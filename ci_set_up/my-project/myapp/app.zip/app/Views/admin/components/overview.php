<?php


?>
<div class="row">
    <br>
	<div class="col-xs-12">
        <div class="row">
            <div class="col-xs-12 col-sm-6">
				COMPONENTS
			</div>
		</div>
	</div>
</div>